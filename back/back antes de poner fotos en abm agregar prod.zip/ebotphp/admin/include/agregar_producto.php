<?php
$query = "INSERT INTO products (description,cattree_idcattree,price)";
$query .= " VALUES ('".$_POST['pdescription']."',".$_POST['cidcattree'].",'".$_POST['price']."');";

mysqli_query($link,$query) or die(mysqli_error());
$lastInsertId = mysqli_insert_id ( $link );
//$fileLocation = $_FILES['fichero_usuario']['tmp_name'];
print_r($_FILES);
$partes_ruta = pathinfo($_FILES['picture']['name']);
$destination = "../imgprod/$lastInsertId.".$partes_ruta['extension'];
echo $destination."/".$_FILES['picture']['tmp_name'];
move_uploaded_file ( $_FILES['picture']['tmp_name'],$destination );
?>